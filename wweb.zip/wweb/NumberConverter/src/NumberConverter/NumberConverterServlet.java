package NumberConverter;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/ConvertNumber")
public class NumberConverterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the number parameter from the request
        String decimalStr = request.getParameter("decimal");

        // Convert the string to an integer
        int decimal = (decimalStr != null && !decimalStr.isEmpty()) ? Integer.parseInt(decimalStr) : 0;

        // Determine which button was clicked
        String convertType = request.getParameter("convertType");
        String result = "";
        String message = "";

        if ("Binary".equals(convertType)) {

            result = Integer.toBinaryString(decimal);
            message = "Decimal number converted to Binary";
        } else if ("Hexadecimal".equals(convertType)) {

            result = Integer.toHexString(decimal);
            message = "Decimal number converted to Hexadecimal";
        } else if ("Octaldecimal".equals(convertType)) {

            result = Integer.toOctalString(decimal);
            message = "Decimal number converted to Octal";
        }

        // Set the content type of the response
        response.setContentType("text/html");

        // Get the PrintWriter object
        PrintWriter out = response.getWriter();

        // Write the HTML response
        out.println("<html>");
        out.println("<head><title>Number Converter</title></head>");
        out.println("<body>");
        out.println("<h1>Converter</h1>");
        out.println("<form method=\"post\">");
        out.println("Enter Base 10 Number <input type=\"text\" name=\"decimal\" value=\"" + decimal + "\"><br>");
        out.println("<input type=\"submit\" name=\"convertType\" value=\"Binary\">");
        out.println("<input type=\"submit\" name=\"convertType\" value=\"Hexadecimal\">");
        out.println("<input type=\"submit\" name=\"convertType\" value=\"Octaldecimal\">");
        out.println("<input type=\"submit\" name=\"convertType\" value=\"Clear\">");
        out.println("</form>");
        out.println("<h2>Result</h2>");
        out.println("<p>Number " + decimal + "</p>");
        out.println("<p>Result " + result + "</p>");
        out.println("<p style=\"color:blue\">" + message + "</p>");
        out.println("</body>");
        out.println("</html>");

        // Forward the request to index.jsp
        request.setAttribute("decimal", decimal);
        request.setAttribute("result", result);
        request.setAttribute("message", message);
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }
}
