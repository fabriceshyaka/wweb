function validateForm() {
    var fullName = document.getElementById("fullName").value.trim();
    var firstName = document.getElementById("firstName").value.trim();
    var lastName = document.getElementById("lastName").value.trim();
    var email = document.getElementById("email").value.trim();
    var phone = document.getElementById("phone").value.trim();
    var address = document.getElementById("address").value.trim();
    var city = document.getElementById("city").value.trim();
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;
    var dob = document.getElementById("dob").value.trim();
    var gender = document.getElementById("gender").value.trim();

    // Add validation for each field as needed...

    if (fullName === "" || firstName === "" || lastName === "" || email === "" || phone === "" || address === "" || city === "" || dob === "" || gender === "") {
        alert("Please fill out all required fields.");
        return false;
    }

    if (password.length < 8) {
        alert("Password must be at least 8 characters long.");
        return false;
    }

    if (!/\d/.test(password)) {
        alert("Password must contain at least one digit.");
        return false;
    }

    if (!/[a-z]/.test(password)) {
        alert("Password must contain at least one lowercase letter.");
        return false;
    }

    if (!/[A-Z]/.test(password)) {
        alert("Password must contain at least one uppercase letter.");
        return false;
    }

    if (!/[\W_]/.test(password)) {
        alert("Password must contain at least one symbol.");
        return false;
    }

    if (password !== confirmPassword) {
        alert("Password and Confirm Password must match.");
        return false;
    }

    // After successful validation, redirect to the login page
    window.location.href = "login.html";

    return false; // Prevent form submission for demonstration purposes
}

